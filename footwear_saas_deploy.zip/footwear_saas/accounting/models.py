from django.db import models
from django.contrib.auth.models import User
from decimal import Decimal
from django.utils import timezone
from products.models import FootwearProduct, WholesaleCustomer, ProductionOrder
import uuid

# Invoice and billing models
class Invoice(models.Model):
    """Invoice for customer orders"""
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('sent', 'Sent'),
        ('paid', 'Paid'),
        ('partial', 'Partially Paid'),
        ('overdue', 'Overdue'),
        ('cancelled', 'Cancelled'),
    ]
    
    INVOICE_TYPES = [
        ('standard', 'Standard Invoice'),
        ('proforma', 'Proforma Invoice'),
        ('credit_note', 'Credit Note'),
        ('debit_note', 'Debit Note'),
    ]
    
    # Invoice identification
    invoice_number = models.CharField(max_length=50, unique=True)
    invoice_type = models.CharField(max_length=20, choices=INVOICE_TYPES, default='standard')
    reference_number = models.CharField(max_length=100, blank=True)
    
    # Customer information
    customer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='invoices')
    wholesale_customer = models.ForeignKey(WholesaleCustomer, null=True, blank=True, on_delete=models.CASCADE)
    
    # Billing details
    billing_name = models.CharField(max_length=200)
    billing_address = models.TextField()
    billing_email = models.EmailField()
    billing_phone = models.CharField(max_length=20, blank=True)
    tax_id = models.CharField(max_length=50, blank=True)
    
    # Financial details
    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    tax_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    shipping_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    paid_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    
    # Dates
    invoice_date = models.DateField(default=timezone.now)
    due_date = models.DateField()
    sent_date = models.DateTimeField(null=True, blank=True)
    paid_date = models.DateTimeField(null=True, blank=True)
    
    # Status and metadata
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    notes = models.TextField(blank=True)
    terms_conditions = models.TextField(blank=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_invoices')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def save(self, *args, **kwargs):
        if not self.invoice_number:
            self.invoice_number = f"INV{timezone.now().strftime('%Y%m%d')}{self.pk or '001'}"
        
        # Calculate totals
        self.total_amount = self.subtotal - self.discount_amount + self.tax_amount + self.shipping_amount
        
        # Update status based on payments
        if self.paid_amount >= self.total_amount:
            self.status = 'paid'
            if not self.paid_date:
                self.paid_date = timezone.now()
        elif self.paid_amount > 0:
            self.status = 'partial'
        elif self.due_date < timezone.now().date() and self.status not in ['paid', 'cancelled']:
            self.status = 'overdue'
            
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"Invoice {self.invoice_number}"
    
    @property
    def balance_due(self):
        return self.total_amount - self.paid_amount
    
    @property
    def is_overdue(self):
        return self.due_date < timezone.now().date() and self.status not in ['paid', 'cancelled']

class InvoiceItem(models.Model):
    """Individual items on an invoice"""
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(FootwearProduct, on_delete=models.CASCADE)
    description = models.CharField(max_length=500)
    quantity = models.DecimalField(max_digits=10, decimal_places=3)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    discount_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    line_total = models.DecimalField(max_digits=12, decimal_places=2)
    
    # Additional details
    size = models.CharField(max_length=20, blank=True)
    color = models.CharField(max_length=50, blank=True)
    custom_specifications = models.TextField(blank=True)
    
    def save(self, *args, **kwargs):
        # Calculate line total
        discount_amount = (self.unit_price * self.quantity) * (self.discount_percentage / 100)
        self.line_total = (self.unit_price * self.quantity) - discount_amount
        super().save(*args, **kwargs)
        
        # Update invoice totals
        self.invoice.subtotal = sum(item.line_total for item in self.invoice.items.all())
        self.invoice.save()
    
    def __str__(self):
        return f"{self.description} (Qty: {self.quantity})"

# Payment tracking
class Payment(models.Model):
    """Payment records for invoices"""
    PAYMENT_METHODS = [
        ('cash', 'Cash'),
        ('check', 'Check'),
        ('credit_card', 'Credit Card'),
        ('bank_transfer', 'Bank Transfer'),
        ('paypal', 'PayPal'),
        ('stripe', 'Stripe'),
        ('other', 'Other'),
    ]
    
    PAYMENT_STATUS = [
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('refunded', 'Refunded'),
    ]
    
    payment_id = models.UUIDField(default=uuid.uuid4, unique=True)
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='payments')
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHODS)
    payment_date = models.DateTimeField()
    status = models.CharField(max_length=20, choices=PAYMENT_STATUS, default='pending')
    
    # Payment details
    transaction_id = models.CharField(max_length=100, blank=True)
    reference_number = models.CharField(max_length=100, blank=True)
    notes = models.TextField(blank=True)
    
    # Processing info
    processed_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        
        # Update invoice paid amount
        if self.status == 'completed':
            completed_payments = self.invoice.payments.filter(status='completed')
            self.invoice.paid_amount = sum(p.amount for p in completed_payments)
            self.invoice.save()
    
    def __str__(self):
        return f"Payment {self.payment_id} - ${self.amount}"

# Accounting and financial tracking
class ChartOfAccounts(models.Model):
    """Chart of accounts for financial tracking"""
    ACCOUNT_TYPES = [
        ('asset', 'Asset'),
        ('liability', 'Liability'),
        ('equity', 'Equity'),
        ('revenue', 'Revenue'),
        ('expense', 'Expense'),
        ('cogs', 'Cost of Goods Sold'),
    ]
    
    account_code = models.CharField(max_length=20, unique=True)
    account_name = models.CharField(max_length=100)
    account_type = models.CharField(max_length=20, choices=ACCOUNT_TYPES)
    parent_account = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE)
    description = models.TextField(blank=True)
    active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.account_code} - {self.account_name}"

class JournalEntry(models.Model):
    """Double-entry accounting journal entries"""
    entry_number = models.CharField(max_length=50, unique=True)
    entry_date = models.DateField()
    description = models.CharField(max_length=200)
    reference = models.CharField(max_length=100, blank=True)  # Invoice number, etc.
    
    # Related records
    invoice = models.ForeignKey(Invoice, null=True, blank=True, on_delete=models.CASCADE)
    payment = models.ForeignKey(Payment, null=True, blank=True, on_delete=models.CASCADE)
    production_order = models.ForeignKey(ProductionOrder, null=True, blank=True, on_delete=models.CASCADE)
    
    # Metadata
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def save(self, *args, **kwargs):
        if not self.entry_number:
            self.entry_number = f"JE{timezone.now().strftime('%Y%m%d')}{self.pk or '001'}"
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"JE {self.entry_number} - {self.description}"
    
    @property
    def is_balanced(self):
        """Check if debits equal credits"""
        total_debits = sum(line.debit_amount for line in self.lines.all())
        total_credits = sum(line.credit_amount for line in self.lines.all())
        return total_debits == total_credits

class JournalEntryLine(models.Model):
    """Individual lines in a journal entry"""
    journal_entry = models.ForeignKey(JournalEntry, on_delete=models.CASCADE, related_name='lines')
    account = models.ForeignKey(ChartOfAccounts, on_delete=models.CASCADE)
    description = models.CharField(max_length=200)
    debit_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    credit_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    
    def __str__(self):
        return f"{self.account.account_name} - Dr: ${self.debit_amount}, Cr: ${self.credit_amount}"

# Financial reports and analytics
class FinancialPeriod(models.Model):
    """Define financial periods for reporting"""
    PERIOD_TYPES = [
        ('monthly', 'Monthly'),
        ('quarterly', 'Quarterly'),
        ('yearly', 'Yearly'),
    ]
    
    name = models.CharField(max_length=100)
    period_type = models.CharField(max_length=20, choices=PERIOD_TYPES)
    start_date = models.DateField()
    end_date = models.DateField()
    closed = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.name} ({self.start_date} to {self.end_date})"

class InventoryValuation(models.Model):
    """Track inventory costs for financial reporting"""
    product = models.ForeignKey(FootwearProduct, on_delete=models.CASCADE)
    valuation_date = models.DateField()
    quantity_on_hand = models.IntegerField()
    unit_cost = models.DecimalField(max_digits=10, decimal_places=2)
    total_value = models.DecimalField(max_digits=12, decimal_places=2)
    
    # Costing method details
    material_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    labor_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    overhead_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    def save(self, *args, **kwargs):
        self.unit_cost = self.material_cost + self.labor_cost + self.overhead_cost
        self.total_value = self.quantity_on_hand * self.unit_cost
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.product.name} - {self.valuation_date}"

# Tax management
class TaxRate(models.Model):
    """Tax rates for different jurisdictions"""
    name = models.CharField(max_length=100)
    rate_percentage = models.DecimalField(max_digits=5, decimal_places=4)  # e.g., 8.2500 for 8.25%
    jurisdiction = models.CharField(max_length=100)  # State, country, etc.
    tax_type = models.CharField(max_length=50)  # Sales tax, VAT, etc.
    effective_date = models.DateField()
    expiry_date = models.DateField(null=True, blank=True)
    active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.name} ({self.rate_percentage}%)"

class CustomerTaxSettings(models.Model):
    """Tax settings for customers"""
    customer = models.OneToOneField(User, on_delete=models.CASCADE)
    tax_exempt = models.BooleanField(default=False)
    tax_exemption_number = models.CharField(max_length=50, blank=True)
    default_tax_rate = models.ForeignKey(TaxRate, null=True, blank=True, on_delete=models.SET_NULL)
    
    def __str__(self):
        return f"Tax settings for {self.customer.username}"
