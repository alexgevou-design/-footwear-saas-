# Django signals for accounting app
from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Invoice, Payment, JournalEntry, JournalEntryLine, ChartOfAccounts

@receiver(post_save, sender=Invoice)
def create_invoice_journal_entry(sender, instance, created, **kwargs):
    """Create journal entry when invoice is created"""
    if created and instance.status != 'draft':
        # Get chart of accounts
        try:
            ar_account = ChartOfAccounts.objects.get(account_code='1200')  # Accounts Receivable
            sales_account = ChartOfAccounts.objects.get(account_code='4000')  # Sales Revenue
            
            # Create journal entry
            journal_entry = JournalEntry.objects.create(
                description=f'Invoice {instance.invoice_number}',
                entry_date=instance.invoice_date,
                reference=instance.invoice_number,
                invoice=instance,
                created_by=instance.created_by
            )
            
            # Debit Accounts Receivable
            JournalEntryLine.objects.create(
                journal_entry=journal_entry,
                account=ar_account,
                description=f'Invoice {instance.invoice_number} - A/R',
                debit_amount=instance.total_amount,
                credit_amount=0
            )
            
            # Credit Sales Revenue
            JournalEntryLine.objects.create(
                journal_entry=journal_entry,
                account=sales_account,
                description=f'Invoice {instance.invoice_number} - Sales',
                debit_amount=0,
                credit_amount=instance.total_amount
            )
            
        except ChartOfAccounts.DoesNotExist:
            pass  # Accounts not set up yet

@receiver(post_save, sender=Payment)
def create_payment_journal_entry(sender, instance, created, **kwargs):
    """Create journal entry when payment is received"""
    if instance.status == 'completed':
        try:
            cash_account = ChartOfAccounts.objects.get(account_code='1000')  # Cash
            ar_account = ChartOfAccounts.objects.get(account_code='1200')  # Accounts Receivable
            
            # Create journal entry
            journal_entry = JournalEntry.objects.create(
                description=f'Payment {instance.payment_id}',
                entry_date=instance.payment_date.date(),
                reference=str(instance.payment_id),
                payment=instance,
                created_by=instance.processed_by
            )
            
            # Debit Cash
            JournalEntryLine.objects.create(
                journal_entry=journal_entry,
                account=cash_account,
                description=f'Payment {instance.payment_id} - Cash',
                debit_amount=instance.amount,
                credit_amount=0
            )
            
            # Credit Accounts Receivable
            JournalEntryLine.objects.create(
                journal_entry=journal_entry,
                account=ar_account,
                description=f'Payment {instance.payment_id} - A/R',
                debit_amount=0,
                credit_amount=instance.amount
            )
            
        except ChartOfAccounts.DoesNotExist:
            pass  # Accounts not set up yet