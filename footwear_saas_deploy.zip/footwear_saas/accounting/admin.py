from django.contrib import admin
from django.utils.html import format_html
from django.db.models import Sum
from .models import (
    Invoice, InvoiceItem, Payment, ChartOfAccounts, JournalEntry, JournalEntryLine,
    TaxRate, CustomerTaxSettings, InventoryValuation, FinancialPeriod
)

class InvoiceItemInline(admin.TabularInline):
    model = InvoiceItem
    extra = 1
    readonly_fields = ['line_total']

class PaymentInline(admin.TabularInline):
    model = Payment
    extra = 0
    readonly_fields = ['payment_id', 'created_at']

@admin.register(Invoice)
class InvoiceAdmin(admin.ModelAdmin):
    list_display = ['invoice_number', 'customer', 'billing_name', 'total_amount', 'status', 'due_date', 'is_overdue']
    list_filter = ['status', 'invoice_type', 'invoice_date', 'due_date']
    search_fields = ['invoice_number', 'billing_name', 'customer__username', 'reference_number']
    list_editable = ['status']
    readonly_fields = ['invoice_number', 'total_amount', 'balance_due', 'is_overdue', 'created_at', 'updated_at']
    date_hierarchy = 'invoice_date'
    inlines = [InvoiceItemInline, PaymentInline]
    
    fieldsets = (
        ('Invoice Information', {
            'fields': ('invoice_number', 'invoice_type', 'reference_number', 'invoice_date', 'due_date')
        }),
        ('Customer Information', {
            'fields': ('customer', 'wholesale_customer', 'billing_name', 'billing_address', 
                      'billing_email', 'billing_phone', 'tax_id')
        }),
        ('Financial Details', {
            'fields': ('subtotal', 'discount_amount', 'tax_amount', 'shipping_amount', 
                      'total_amount', 'paid_amount', 'balance_due')
        }),
        ('Status & Dates', {
            'fields': ('status', 'sent_date', 'paid_date', 'is_overdue')
        }),
        ('Additional Information', {
            'fields': ('notes', 'terms_conditions', 'created_by', 'created_at', 'updated_at')
        }),
    )
    
    def get_readonly_fields(self, request, obj=None):
        if obj:  # editing an existing object
            return self.readonly_fields + ('created_by',)
        return self.readonly_fields
    
    def save_model(self, request, obj, form, change):
        if not change:  # creating a new object
            obj.created_by = request.user
        super().save_model(request, obj, form, change)
    
    def is_overdue(self, obj):
        if obj.is_overdue:
            return format_html('<span style="color: red;">Yes</span>')
        return 'No'
    is_overdue.short_description = 'Overdue'

@admin.register(InvoiceItem)
class InvoiceItemAdmin(admin.ModelAdmin):
    list_display = ['invoice', 'product', 'description', 'quantity', 'unit_price', 'line_total']
    list_filter = ['invoice__status', 'product__category']
    search_fields = ['invoice__invoice_number', 'product__name', 'description']
    readonly_fields = ['line_total']

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ['payment_id', 'invoice', 'amount', 'payment_method', 'status', 'payment_date']
    list_filter = ['status', 'payment_method', 'payment_date']
    search_fields = ['payment_id', 'invoice__invoice_number', 'transaction_id', 'reference_number']
    list_editable = ['status']
    readonly_fields = ['payment_id', 'created_at']
    date_hierarchy = 'payment_date'
    
    def get_readonly_fields(self, request, obj=None):
        if obj:  # editing an existing object
            return self.readonly_fields + ('processed_by',)
        return self.readonly_fields
    
    def save_model(self, request, obj, form, change):
        if not change:  # creating a new object
            obj.processed_by = request.user
        super().save_model(request, obj, form, change)

@admin.register(ChartOfAccounts)
class ChartOfAccountsAdmin(admin.ModelAdmin):
    list_display = ['account_code', 'account_name', 'account_type', 'parent_account', 'active']
    list_filter = ['account_type', 'active']
    search_fields = ['account_code', 'account_name']
    list_editable = ['active']

class JournalEntryLineInline(admin.TabularInline):
    model = JournalEntryLine
    extra = 2

@admin.register(JournalEntry)
class JournalEntryAdmin(admin.ModelAdmin):
    list_display = ['entry_number', 'entry_date', 'description', 'is_balanced', 'created_by']
    list_filter = ['entry_date', 'created_by']
    search_fields = ['entry_number', 'description', 'reference']
    readonly_fields = ['entry_number', 'is_balanced', 'created_at']
    date_hierarchy = 'entry_date'
    inlines = [JournalEntryLineInline]
    
    def get_readonly_fields(self, request, obj=None):
        if obj:  # editing an existing object
            return self.readonly_fields + ('created_by',)
        return self.readonly_fields
    
    def save_model(self, request, obj, form, change):
        if not change:  # creating a new object
            obj.created_by = request.user
        super().save_model(request, obj, form, change)
    
    def is_balanced(self, obj):
        if obj.is_balanced:
            return format_html('<span style="color: green;">✓ Balanced</span>')
        return format_html('<span style="color: red;">✗ Unbalanced</span>')
    is_balanced.short_description = 'Balanced'

@admin.register(JournalEntryLine)
class JournalEntryLineAdmin(admin.ModelAdmin):
    list_display = ['journal_entry', 'account', 'description', 'debit_amount', 'credit_amount']
    list_filter = ['account__account_type', 'journal_entry__entry_date']
    search_fields = ['journal_entry__entry_number', 'account__account_name', 'description']

@admin.register(TaxRate)
class TaxRateAdmin(admin.ModelAdmin):
    list_display = ['name', 'rate_percentage', 'jurisdiction', 'tax_type', 'effective_date', 'active']
    list_filter = ['tax_type', 'jurisdiction', 'active']
    search_fields = ['name', 'jurisdiction']
    list_editable = ['active']
    date_hierarchy = 'effective_date'

@admin.register(CustomerTaxSettings)
class CustomerTaxSettingsAdmin(admin.ModelAdmin):
    list_display = ['customer', 'tax_exempt', 'tax_exemption_number', 'default_tax_rate']
    list_filter = ['tax_exempt']
    search_fields = ['customer__username', 'tax_exemption_number']

@admin.register(InventoryValuation)
class InventoryValuationAdmin(admin.ModelAdmin):
    list_display = ['product', 'valuation_date', 'quantity_on_hand', 'unit_cost', 'total_value']
    list_filter = ['valuation_date', 'product__category']
    search_fields = ['product__name']
    readonly_fields = ['unit_cost', 'total_value', 'created_at']
    date_hierarchy = 'valuation_date'

@admin.register(FinancialPeriod)
class FinancialPeriodAdmin(admin.ModelAdmin):
    list_display = ['name', 'period_type', 'start_date', 'end_date', 'closed']
    list_filter = ['period_type', 'closed']
    search_fields = ['name']
    list_editable = ['closed']