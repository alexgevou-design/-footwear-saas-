#!/bin/bash

# Render.com build script
echo "🚀 Building FootwearCraft SaaS Platform..."

# Install dependencies
pip install -r requirements.txt

# Collect static files
python manage.py collectstatic --noinput

# Run migrations
python manage.py migrate

# Create superuser if it doesn't exist
echo "Creating admin user..."
python manage.py shell <<EOF
from django.contrib.auth import get_user_model
User = get_user_model()
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser('admin', 'admin@footwearcraft.com', 'admin123')
    print('Admin user created successfully!')
else:
    print('Admin user already exists.')
EOF

echo "✅ Build complete!"