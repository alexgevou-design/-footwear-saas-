from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework.authtoken.views import obtain_auth_token
from . import views

router = DefaultRouter()
router.register(r'products', views.FootwearProductViewSet)
router.register(r'categories', views.FootwearCategoryViewSet)
router.register(r'materials', views.MaterialViewSet)
router.register(r'size-charts', views.SizeChartViewSet)
router.register(r'size-conversions', views.SizeConversionViewSet)
router.register(r'wholesale-customers', views.WholesaleCustomerViewSet)
router.register(r'custom-designs', views.CustomDesignViewSet)
router.register(r'production-orders', views.ProductionOrderViewSet)
router.register(r'invoices', views.InvoiceViewSet)
router.register(r'payments', views.PaymentViewSet)
router.register(r'accounts', views.ChartOfAccountsViewSet)
router.register(r'journal-entries', views.JournalEntryViewSet)
router.register(r'tax-rates', views.TaxRateViewSet)
router.register(r'inventory-valuations', views.InventoryValuationViewSet)
router.register(r'dashboard', views.DashboardViewSet, basename='dashboard')

urlpatterns = [
    path('auth/token/', obtain_auth_token, name='api_token_auth'),
    path('', include(router.urls)),
]