from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import Sum, Count, Q
from django.utils import timezone
from datetime import datetime, timedelta
from decimal import Decimal

from products.models import (
    FootwearProduct, FootwearCategory, Material, SizeChart, SizeConversion,
    BillOfMaterials, WholesaleCustomer, CustomDesign, ProductionOrder
)
from accounting.models import (
    Invoice, InvoiceItem, Payment, ChartOfAccounts, JournalEntry,
    TaxRate, InventoryValuation
)
from .serializers import (
    FootwearProductSerializer, FootwearProductCreateSerializer,
    FootwearCategorySerializer, MaterialSerializer, SizeChartSerializer,
    SizeConversionSerializer, BillOfMaterialsSerializer,
    WholesaleCustomerSerializer, CustomDesignSerializer,
    ProductionOrderSerializer, InvoiceSerializer, InvoiceCreateSerializer,
    InvoiceItemSerializer, PaymentSerializer, ChartOfAccountsSerializer,
    JournalEntrySerializer, TaxRateSerializer, InventoryValuationSerializer,
    DashboardStatsSerializer, SizeConverterSerializer
)

class FootwearProductViewSet(viewsets.ModelViewSet):
    queryset = FootwearProduct.objects.all()
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['category', 'gender', 'active', 'customizable']
    search_fields = ['name', 'sku', 'description']
    ordering_fields = ['name', 'base_price', 'created_at']
    ordering = ['-created_at']
    
    def get_serializer_class(self):
        if self.action in ['create', 'update', 'partial_update']:
            return FootwearProductCreateSerializer
        return FootwearProductSerializer
    
    @action(detail=True, methods=['get'])
    def calculate_cost(self, request, pk=None):
        """Calculate total production cost for a product"""
        product = self.get_object()
        bom_items = product.bom_items.all()
        total_cost = sum(item.cost for item in bom_items)
        
        return Response({
            'product_id': product.id,
            'total_cost': total_cost,
            'bom_breakdown': BillOfMaterialsSerializer(bom_items, many=True).data
        })
    
    @action(detail=False, methods=['get'])
    def popular_products(self, request):
        """Get most popular products based on orders"""
        # This would normally use order data, simplified for demo
        products = self.get_queryset()[:10]
        serializer = self.get_serializer(products, many=True)
        return Response(serializer.data)

class FootwearCategoryViewSet(viewsets.ModelViewSet):
    queryset = FootwearCategory.objects.all()
    serializer_class = FootwearCategorySerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['name', 'description']

class MaterialViewSet(viewsets.ModelViewSet):
    queryset = Material.objects.all()
    serializer_class = MaterialSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['material_type', 'supplier']
    search_fields = ['name', 'color', 'supplier']

class SizeChartViewSet(viewsets.ModelViewSet):
    queryset = SizeChart.objects.all()
    serializer_class = SizeChartSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['region', 'gender']

class SizeConversionViewSet(viewsets.ModelViewSet):
    queryset = SizeConversion.objects.all()
    serializer_class = SizeConversionSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['size_chart__region', 'size_chart__gender']
    
    @action(detail=False, methods=['post'])
    def convert_size(self, request):
        """Convert size between different regional standards"""
        serializer = SizeConverterSerializer(data=request.data)
        if serializer.is_valid():
            from_size = serializer.validated_data['from_size']
            from_region = serializer.validated_data['from_region']
            to_region = serializer.validated_data['to_region']
            gender = serializer.validated_data['gender']
            
            try:
                # Find the source size
                from_conversion = SizeConversion.objects.get(
                    size_chart__region=from_region,
                    size_chart__gender=gender,
                    size_value=from_size
                )
                
                # Find equivalent size in target region
                to_conversion = SizeConversion.objects.get(
                    size_chart__region=to_region,
                    size_chart__gender=gender,
                    length_mm=from_conversion.length_mm
                )
                
                return Response({
                    'from_size': from_size,
                    'from_region': from_region,
                    'to_region': to_region,
                    'converted_size': to_conversion.size_value,
                    'length_mm': to_conversion.length_mm
                })
            
            except SizeConversion.DoesNotExist:
                return Response(
                    {'error': 'Size conversion not found'},
                    status=status.HTTP_404_NOT_FOUND
                )
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class WholesaleCustomerViewSet(viewsets.ModelViewSet):
    queryset = WholesaleCustomer.objects.all()
    serializer_class = WholesaleCustomerSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['discount_tier', 'approved']
    search_fields = ['business_name', 'contact_person', 'email']

class CustomDesignViewSet(viewsets.ModelViewSet):
    queryset = CustomDesign.objects.all()
    serializer_class = CustomDesignSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['customer', 'base_product', 'approved']
    search_fields = ['design_name', 'customer__username']
    
    def perform_create(self, serializer):
        serializer.save(customer=self.request.user)

class ProductionOrderViewSet(viewsets.ModelViewSet):
    queryset = ProductionOrder.objects.all()
    serializer_class = ProductionOrderSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['status', 'product']
    search_fields = ['order_number', 'product__name']
    ordering = ['-created_at']
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)
    
    @action(detail=True, methods=['post'])
    def update_status(self, request, pk=None):
        """Update production order status"""
        order = self.get_object()
        new_status = request.data.get('status')
        
        if new_status in dict(ProductionOrder.STATUS_CHOICES):
            order.status = new_status
            if new_status == 'completed' and not order.actual_completion:
                order.actual_completion = timezone.now().date()
            order.save()
            
            return Response({'status': 'Status updated successfully'})
        
        return Response(
            {'error': 'Invalid status'},
            status=status.HTTP_400_BAD_REQUEST
        )

# Accounting ViewSets
class InvoiceViewSet(viewsets.ModelViewSet):
    queryset = Invoice.objects.all()
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['status', 'customer', 'wholesale_customer']
    search_fields = ['invoice_number', 'billing_name', 'reference_number']
    ordering = ['-created_at']
    
    def get_serializer_class(self):
        if self.action in ['create']:
            return InvoiceCreateSerializer
        return InvoiceSerializer
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)
    
    @action(detail=True, methods=['post'])
    def send_invoice(self, request, pk=None):
        """Send invoice to customer via email"""
        invoice = self.get_object()
        # Email sending logic would go here
        invoice.sent_date = timezone.now()
        invoice.status = 'sent'
        invoice.save()
        
        return Response({'status': 'Invoice sent successfully'})
    
    @action(detail=True, methods=['post'])
    def record_payment(self, request, pk=None):
        """Record a payment for the invoice"""
        invoice = self.get_object()
        payment_data = request.data
        
        payment = Payment.objects.create(
            invoice=invoice,
            amount=payment_data['amount'],
            payment_method=payment_data['payment_method'],
            payment_date=payment_data.get('payment_date', timezone.now()),
            status='completed',
            processed_by=request.user,
            transaction_id=payment_data.get('transaction_id', ''),
            notes=payment_data.get('notes', '')
        )
        
        return Response(PaymentSerializer(payment).data)
    
    @action(detail=False, methods=['get'])
    def overdue_invoices(self, request):
        """Get all overdue invoices"""
        overdue = self.get_queryset().filter(
            due_date__lt=timezone.now().date(),
            status__in=['sent', 'partial']
        )
        serializer = self.get_serializer(overdue, many=True)
        return Response(serializer.data)

class PaymentViewSet(viewsets.ModelViewSet):
    queryset = Payment.objects.all()
    serializer_class = PaymentSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['status', 'payment_method', 'invoice']
    search_fields = ['transaction_id', 'reference_number']
    ordering = ['-created_at']
    
    def perform_create(self, serializer):
        serializer.save(processed_by=self.request.user)

class ChartOfAccountsViewSet(viewsets.ModelViewSet):
    queryset = ChartOfAccounts.objects.all()
    serializer_class = ChartOfAccountsSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['account_type', 'active']
    search_fields = ['account_code', 'account_name']

class JournalEntryViewSet(viewsets.ModelViewSet):
    queryset = JournalEntry.objects.all()
    serializer_class = JournalEntrySerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['entry_date']
    search_fields = ['entry_number', 'description', 'reference']
    ordering = ['-entry_date']
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

class TaxRateViewSet(viewsets.ModelViewSet):
    queryset = TaxRate.objects.filter(active=True)
    serializer_class = TaxRateSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['jurisdiction', 'tax_type']

class InventoryValuationViewSet(viewsets.ModelViewSet):
    queryset = InventoryValuation.objects.all()
    serializer_class = InventoryValuationSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['product', 'valuation_date']
    ordering = ['-valuation_date']

# Dashboard and Analytics
class DashboardViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]
    
    @action(detail=False, methods=['get'])
    def stats(self, request):
        """Get dashboard statistics"""
        # Calculate various statistics
        today = timezone.now().date()
        thirty_days_ago = today - timedelta(days=30)
        
        # Revenue calculations
        total_revenue = Invoice.objects.filter(
            status='paid'
        ).aggregate(Sum('total_amount'))['total_amount__sum'] or 0
        
        # Order counts
        total_orders = ProductionOrder.objects.count()
        pending_invoices = Invoice.objects.filter(status__in=['draft', 'sent']).count()
        overdue_invoices = Invoice.objects.filter(
            due_date__lt=today,
            status__in=['sent', 'partial']
        ).count()
        
        # Customer counts
        active_customers = WholesaleCustomer.objects.filter(approved=True).count()
        
        # Production
        products_in_production = ProductionOrder.objects.filter(
            status='in_production'
        ).count()
        
        # Inventory value
        inventory_value = InventoryValuation.objects.filter(
            valuation_date=today
        ).aggregate(Sum('total_value'))['total_value__sum'] or 0
        
        # Monthly revenue (last 12 months)
        monthly_revenue = []
        for i in range(12):
            month_start = today.replace(day=1) - timedelta(days=30*i)
            month_end = (month_start + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            
            revenue = Invoice.objects.filter(
                status='paid',
                paid_date__range=[month_start, month_end]
            ).aggregate(Sum('total_amount'))['total_amount__sum'] or 0
            
            monthly_revenue.append({
                'month': month_start.strftime('%Y-%m'),
                'revenue': float(revenue)
            })
        
        # Top products (simplified)
        top_products = []
        for product in FootwearProduct.objects.filter(active=True)[:5]:
            top_products.append({
                'name': product.name,
                'orders': ProductionOrder.objects.filter(product=product).count(),
                'revenue': float(product.base_price * 10)  # Simplified calculation
            })
        
        # Recent orders
        recent_orders = ProductionOrder.objects.all()[:10]
        
        stats_data = {
            'total_revenue': total_revenue,
            'total_orders': total_orders,
            'pending_invoices': pending_invoices,
            'overdue_invoices': overdue_invoices,
            'active_customers': active_customers,
            'products_in_production': products_in_production,
            'inventory_value': inventory_value,
            'monthly_revenue': monthly_revenue,
            'top_products': top_products,
            'recent_orders': recent_orders
        }
        
        serializer = DashboardStatsSerializer(stats_data)
        return Response(serializer.data)